#include <stdio.h>
struct student {
    char firstName[50];
    int roll;
    float m1,m2,m3;
    float avg;
} s[25];

int main() {
    int i;
    printf("Enter information of students:\n");

   
    for (i = 0; i <25; i++) {
        printf("\nENTER ROLL NO:");
        scanf("%d",&s[i].roll);
        printf("\nEnter first name: ");
        scanf("%s", s[i].firstName);
        printf("Enter marks: ");
        scanf("%f%f%f", &s[i].m1,&s[i].m2,&s[i].m3);
    }
    printf("Displaying Information:\n\n");
    for (i = 0; i < 25; i++) 
    {
        s[i].avg=(s[i].m1+s[i].m2+s[i].m3)/3;
    }

    for (i = 0; i < 25; i++) {
        printf("\nRoll number: %d\n", s[i].roll);
        printf("\nFirst name: ");
        puts(s[i].firstName);
        printf("\nMarks: %.f", s[i].avg);
       
    }
    return 0;
}